import 'package:flutter/material.dart';

const Color mainColor = Color(0xff703efe);

const String loginScreen = '/login';
const String registerScreen = '/register';
